﻿
namespace Avaliativa_5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNota = new Label();
            lblNome = new Label();
            txtNomeAluno = new TextBox();
            txtNotaAluno = new TextBox();
            lstAlunos = new ListBox();
            btnAdicionar = new Button();
            btnAlterar = new Button();
            btnGerarRelatorio = new Button();
            txtRelatorio = new TextBox();
            SuspendLayout();
            // 
            // lblNota
            // 
            lblNota.AutoSize = true;
            lblNota.Font = new Font("Segoe UI", 15F);
            lblNota.Location = new Point(201, 44);
            lblNota.Margin = new Padding(2, 0, 2, 0);
            lblNota.Name = "lblNota";
            lblNota.Size = new Size(60, 28);
            lblNota.TabIndex = 0;
            lblNota.Text = "Nota:";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI", 15F);
            lblNome.Location = new Point(201, 12);
            lblNome.Margin = new Padding(2, 0, 2, 0);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(156, 28);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome do Aluno:";
            lblNome.Click += label2_Click;
            // 
            // txtNomeAluno
            // 
            txtNomeAluno.Font = new Font("Segoe UI", 15F);
            txtNomeAluno.Location = new Point(371, 12);
            txtNomeAluno.Margin = new Padding(2, 2, 2, 2);
            txtNomeAluno.Name = "txtNomeAluno";
            txtNomeAluno.Size = new Size(175, 34);
            txtNomeAluno.TabIndex = 2;
            // 
            // txtNotaAluno
            // 
            txtNotaAluno.Font = new Font("Segoe UI", 15F);
            txtNotaAluno.Location = new Point(262, 44);
            txtNotaAluno.Margin = new Padding(2, 2, 2, 2);
            txtNotaAluno.Name = "txtNotaAluno";
            txtNotaAluno.Size = new Size(284, 34);
            txtNotaAluno.TabIndex = 3;
            // 
            // lstAlunos
            // 
            lstAlunos.FormattingEnabled = true;
            lstAlunos.ItemHeight = 15;
            lstAlunos.Location = new Point(8, 7);
            lstAlunos.Margin = new Padding(2, 2, 2, 2);
            lstAlunos.Name = "lstAlunos";
            lstAlunos.Size = new Size(183, 139);
            lstAlunos.TabIndex = 4;
            // 
            // btnAdicionar
            // 
            btnAdicionar.Font = new Font("Segoe UI", 15F);
            btnAdicionar.Location = new Point(8, 232);
            btnAdicionar.Margin = new Padding(2, 2, 2, 2);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(182, 40);
            btnAdicionar.TabIndex = 5;
            btnAdicionar.Text = "Adicionar Aluno";
            btnAdicionar.UseVisualStyleBackColor = true;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // btnAlterar
            // 
            btnAlterar.Font = new Font("Segoe UI", 15F);
            btnAlterar.Location = new Point(387, 232);
            btnAlterar.Margin = new Padding(2, 2, 2, 2);
            btnAlterar.Name = "btnAlterar";
            btnAlterar.Size = new Size(158, 40);
            btnAlterar.TabIndex = 6;
            btnAlterar.Text = "Alterar Aluno Selecionado";
            btnAlterar.UseVisualStyleBackColor = true;
            btnAlterar.Click += btnAlterar_Click;
            // 
            // btnGerarRelatorio
            // 
            btnGerarRelatorio.Font = new Font("Segoe UI", 15F);
            btnGerarRelatorio.Location = new Point(209, 232);
            btnGerarRelatorio.Margin = new Padding(2, 2, 2, 2);
            btnGerarRelatorio.Name = "btnGerarRelatorio";
            btnGerarRelatorio.Size = new Size(169, 40);
            btnGerarRelatorio.TabIndex = 7;
            btnGerarRelatorio.Text = "Gerar Relatório";
            btnGerarRelatorio.UseVisualStyleBackColor = true;
            btnGerarRelatorio.Click += btnGerarRelatorio_Click;
            // 
            // txtRelatorio
            // 
            txtRelatorio.Location = new Point(209, 85);
            txtRelatorio.Margin = new Padding(2, 2, 2, 2);
            txtRelatorio.Multiline = true;
            txtRelatorio.Name = "txtRelatorio";
            txtRelatorio.ScrollBars = ScrollBars.Both;
            txtRelatorio.Size = new Size(318, 131);
            txtRelatorio.TabIndex = 8;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(560, 270);
            Controls.Add(txtRelatorio);
            Controls.Add(btnGerarRelatorio);
            Controls.Add(btnAlterar);
            Controls.Add(btnAdicionar);
            Controls.Add(lstAlunos);
            Controls.Add(txtNotaAluno);
            Controls.Add(txtNomeAluno);
            Controls.Add(lblNome);
            Controls.Add(lblNota);
            Margin = new Padding(2, 2, 2, 2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Label lblNota;
        private Label lblNome;
        private TextBox txtNomeAluno;
        private TextBox txtNotaAluno;
        private ListBox lstAlunos;
        private Button btnAdicionar;
        private Button btnAlterar;
        private Button btnGerarRelatorio;
        private TextBox txtRelatorio;
    }
}
