using System.Text;

namespace Avaliativa_5
{
    public partial class Form1 : Form
    {
        string[] nomesAlunos = new string[100]; 
        double[] notasAlunos = new double[100]; 
        int totalAlunos = 0; 

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (totalAlunos < nomesAlunos.Length)
            {
                
                if (string.IsNullOrWhiteSpace(txtNomeAluno.Text))
                {
                    MessageBox.Show("Por favor, digite o nome do aluno.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                if (double.TryParse(txtNotaAluno.Text, out double nota))
                {
                    
                    nomesAlunos[totalAlunos] = txtNomeAluno.Text;
                    notasAlunos[totalAlunos] = nota;

                    
                    lstAlunos.Items.Add($"{txtNomeAluno.Text} - {nota}");

                    totalAlunos++; 

                    
                    txtNomeAluno.Clear();
                    txtNotaAluno.Clear();
                    txtNomeAluno.Focus(); 
                }
                else
                {
                    MessageBox.Show("Por favor, digite uma nota v�lida (n�mero).", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Capacidade m�xima de alunos atingida!", "Limite Excedido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            int indiceSelecionado = lstAlunos.SelectedIndex;

            if (indiceSelecionado != -1) 
            {
                
                if (string.IsNullOrWhiteSpace(txtNomeAluno.Text))
                {
                    MessageBox.Show("Por favor, digite o novo nome do aluno para altera��o.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                
                if (double.TryParse(txtNotaAluno.Text, out double novaNota))
                {
                    
                    nomesAlunos[indiceSelecionado] = txtNomeAluno.Text;
                    notasAlunos[indiceSelecionado] = novaNota;

                    
                    lstAlunos.Items[indiceSelecionado] = $"{txtNomeAluno.Text} - {novaNota}";

                    MessageBox.Show("Aluno alterado com sucesso!", "Altera��o", MessageBoxButtons.OK, MessageBoxIcon.Information);

                   
                    txtNomeAluno.Clear();
                    txtNotaAluno.Clear();
                }
                else
                {
                    MessageBox.Show("Por favor, digite uma nota v�lida (n�mero) para altera��o.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecione um aluno na lista para alterar.", "Nenhum Aluno Selecionado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void lstAlunos_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indiceSelecionado = lstAlunos.SelectedIndex;

            if (indiceSelecionado != -1)
            {
                
                txtNomeAluno.Text = nomesAlunos[indiceSelecionado];
                txtNotaAluno.Text = notasAlunos[indiceSelecionado].ToString();
            }
        }

        private void btnGerarRelatorio_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();

            
            sb.AppendLine("--- Relat�rio da Turma ---");
            sb.AppendLine("Alunos Cadastrados:");
            if (totalAlunos == 0)
            {
                sb.AppendLine("Nenhum aluno cadastrado ainda.");
            }
            else
            {
                for (int i = 0; i < totalAlunos; i++)
                {
                    sb.AppendLine($"- {nomesAlunos[i]} (Nota: {notasAlunos[i]:F2})");
                }

                
                double somaNotas = 0;
                for (int i = 0; i < totalAlunos; i++)
                {
                    somaNotas += notasAlunos[i];
                }
                
                double mediaTurma = somaNotas / totalAlunos;
                sb.AppendLine($"\nM�dia da Turma: {mediaTurma:F2}");


                
                double maiorNota = -1;
                string alunoMaiorNota = "";
                if (totalAlunos > 0) 
                {
                    maiorNota = notasAlunos[0]; 
                    alunoMaiorNota = nomesAlunos[0];

                    for (int i = 1; i < totalAlunos; i++)
                    {
                        if (notasAlunos[i] > maiorNota)
                        {
                            maiorNota = notasAlunos[i];
                            alunoMaiorNota = nomesAlunos[i];
                        }
                    }
                }
                sb.AppendLine($"Aluno com a Maior Nota: {alunoMaiorNota} ({maiorNota:F2})");

                
                double menorNota = 11; 
                string alunoMenorNota = "";
                if (totalAlunos > 0)
                {
                    menorNota = notasAlunos[0]; 
                    alunoMenorNota = nomesAlunos[0];

                    for (int i = 1; i < totalAlunos; i++)
                    {
                        if (notasAlunos[i] < menorNota)
                        {
                            menorNota = notasAlunos[i];
                            alunoMenorNota = nomesAlunos[i];
                        }
                    }
                }
                sb.AppendLine($"Aluno com a Menor Nota: {alunoMenorNota} ({menorNota:F2})");

                
                int alunosAprovados = 0;
                for (int i = 0; i < totalAlunos; i++)
                {
                    if (notasAlunos[i] >= 7.0)
                    {
                        alunosAprovados++;
                    }
                }
                sb.AppendLine($"\nAlunos Aprovados (Nota >= 7.0): {alunosAprovados}");
            }

            txtRelatorio.Text = sb.ToString();
        }
    }
}