﻿using System;

class Program
{
    static char[,] board = new char[3, 3];
    static int player1Wins = 0, player2Wins = 0, draws = 0;
    static string player1 = "Jogador 1", player2 = "Jogador 2";
    static Random rand = new Random();

    static void Main()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("=== JOGO DA VELHA ===");
            Console.WriteLine("1. Jogador vs Jogador");
            Console.WriteLine("2. Jogador vs Computador (Fácil)");
            Console.WriteLine("3. Jogador vs Computador (Difícil)");
            Console.WriteLine("4. Ver Ranking");
            Console.WriteLine("0. Sair");
            Console.Write("Escolha uma opção: ");
            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    player1 = "Jogador 1";
                    player2 = "Jogador 2";
                    Jogar(false, false);
                    break;
                case "2":
                    player1 = "Jogador";
                    player2 = "Computador (Fácil)";
                    Jogar(false, true);
                    break;
                case "3":
                    player1 = "Jogador";
                    player2 = "Computador (Difícil)";
                    Jogar(false, true, true);
                    break;
                case "4":
                    ExibirRanking();
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Opção inválida!");
                    Console.ReadKey();
                    break;
            }
        }
    }

    static void Jogar(bool cpuFirst, bool contraCpu, bool modoDificil = false)
    {
        InicializarTabuleiro();
        char jogadorAtual = 'X';
        bool fim = false;

        while (!fim)
        {
            Console.Clear();
            ExibirTabuleiro();
            Console.WriteLine($"Vez de {(jogadorAtual == 'X' ? player1 : player2)} ({jogadorAtual}):");

            if ((jogadorAtual == 'O' && contraCpu))
            {
                if (modoDificil)
                    JogadaComputadorDificil(jogadorAtual);
                else
                    JogadaComputadorFacil(jogadorAtual);
            }
            else
            {
                JogadaJogador(jogadorAtual);
            }

            char vencedor = VerificarVencedor();
            if (vencedor != ' ')
            {
                Console.Clear();
                ExibirTabuleiro();
                Console.WriteLine($"Vitória de {(vencedor == 'X' ? player1 : player2)}!");
                if (vencedor == 'X') player1Wins++;
                else player2Wins++;
                fim = true;
            }
            else if (TabuleiroCompleto())
            {
                Console.Clear();
                ExibirTabuleiro();
                Console.WriteLine("Empate!");
                draws++;
                fim = true;
            }
            else
            {
                jogadorAtual = (jogadorAtual == 'X') ? 'O' : 'X';
            }
        }

        Console.WriteLine("Pressione qualquer tecla para continuar...");
        Console.ReadKey();
    }

    static void InicializarTabuleiro()
    {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                board[i, j] = ' ';
    }

    static void ExibirTabuleiro()
    {
        Console.WriteLine();
        Console.WriteLine("   0   1   2");
        for (int i = 0; i < 3; i++)
        {
            Console.Write($" {i} ");
            for (int j = 0; j < 3; j++)
            {
                Console.Write($" {board[i, j]} ");
                if (j < 2) Console.Write("|");
            }
            if (i < 2) Console.WriteLine("\n  ---+---+---");
        }
        Console.WriteLine("\n");
    }

    static void JogadaJogador(char jogador)
    {
        int linha, coluna;
        while (true)
        {
            Console.Write("Digite linha (0-2): ");
            if (!int.TryParse(Console.ReadLine(), out linha) || linha < 0 || linha > 2) continue;

            Console.Write("Digite coluna (0-2): ");
            if (!int.TryParse(Console.ReadLine(), out coluna) || coluna < 0 || coluna > 2) continue;

            if (board[linha, coluna] == ' ')
            {
                board[linha, coluna] = jogador;
                break;
            }
            else
            {
                Console.WriteLine("Posição já ocupada. Tente novamente.");
            }
        }
    }

    static void JogadaComputadorFacil(char jogador)
    {
        int linha, coluna;
        do
        {
            linha = rand.Next(3);
            coluna = rand.Next(3);
        } while (board[linha, coluna] != ' ');

        board[linha, coluna] = jogador;
    }

    static void JogadaComputadorDificil(char jogador)
    {
        // Estratégia: vencer > bloquear > aleatório
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board[i, j] == ' ')
                {
                    board[i, j] = jogador;
                    if (VerificarVencedor() == jogador)
                        return;
                    board[i, j] = ' ';
                }

        char oponente = (jogador == 'X') ? 'O' : 'X';
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board[i, j] == ' ')
                {
                    board[i, j] = oponente;
                    if (VerificarVencedor() == oponente)
                    {
                        board[i, j] = jogador;
                        return;
                    }
                    board[i, j] = ' ';
                }

        JogadaComputadorFacil(jogador); // fallback
    }

    static char VerificarVencedor()
    {
        for (int i = 0; i < 3; i++)
        {
            if (board[i, 0] != ' ' && board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2])
                return board[i, 0];
            if (board[0, i] != ' ' && board[0, i] == board[1, i] && board[1, i] == board[2, i])
                return board[0, i];
        }
        if (board[0, 0] != ' ' && board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2])
            return board[0, 0];
        if (board[0, 2] != ' ' && board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0])
            return board[0, 2];

        return ' ';
    }

    static bool TabuleiroCompleto()
    {
        foreach (char c in board)
            if (c == ' ') return false;
        return true;
    }

    static void ExibirRanking()
    {
        Console.Clear();
        Console.WriteLine("=== RANKING ===");
        Console.WriteLine($"{player1}: {player1Wins} vitórias");
        Console.WriteLine($"{player2}: {player2Wins} vitórias");
        Console.WriteLine($"Empates: {draws}");
        Console.WriteLine("=================");
        Console.WriteLine("Pressione qualquer tecla para voltar ao menu...");
        Console.ReadKey();
    }
}