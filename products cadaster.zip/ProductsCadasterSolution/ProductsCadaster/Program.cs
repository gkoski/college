﻿int valorcelular = 900;
int valornote = 2100;
int valorcaneta = 2;
int valorcaderno = 15;
int valorsofa = 1700;
int valorcama = 900;
double descontoelet = 0.15;
double descontopap = 0.1;
double descontomov = 0.05;




Console.WriteLine("Qual categoria de produto você deseja? ");

Console.WriteLine("1 - Eletrônicos ");
Console.WriteLine("2 - Papelaria ");
Console.WriteLine("3 - Móveis ");
string categoria = Console.ReadLine();

Console.Clear();
Console.WriteLine($"Categoria escolhida: {categoria}");

switch (categoria)
{
    case "1":
        Console.WriteLine("Qual produto você deseja? ");
        Console.WriteLine("1 - Celular ");
        Console.WriteLine("2 - Notebook ");
        string eletronico = Console.ReadLine();

        switch (eletronico)
        {
            case "1":
                Console.Clear();
                Console.WriteLine("Produto escolhido foi celular");
                Console.WriteLine("A categoria é Eletrônicos");
                Console.WriteLine($"O valor do produto era de {valorcelular}");
                Console.WriteLine($"A porcentagem de desconto é de {descontoelet * 100}%");
                double desccelular = valorcelular * descontoelet;
                Console.WriteLine($"O desconto é de {desccelular}");
                Console.WriteLine($"O valor atual é de {valorcelular - desccelular}");
                break;

            case "2":
                Console.Clear();
                Console.WriteLine("Produto escolhido foi notebook");
                Console.WriteLine("A categoria é Eletrônicos");
                Console.WriteLine($"O valor do produto era de {valornote}");
                Console.WriteLine($"A porcentagem de desconto é de {descontoelet * 100}%");
                double descnote = valornote * descontoelet;
                Console.WriteLine($"O desconto é de {descnote}");
                Console.WriteLine($"O valor atual é de {valornote - descnote}");
                break;

            default:
                Console.WriteLine("Opção inválida.");
                break;
        }
        break;

    case "2":
        Console.WriteLine("Qual produto você deseja? ");
        Console.WriteLine("1 - Caneta ");
        Console.WriteLine("2 - Caderno ");
        string papelaria = Console.ReadLine();

        switch (papelaria)
        {
            case "1":
                Console.Clear();
                Console.WriteLine("Produto escolhido foi caneta");
                Console.WriteLine("A categoria é Papelaria");
                Console.WriteLine($"O valor do produto era de {valorcaneta}");
                Console.WriteLine($"A porcentagem de desconto é de {descontopap * 100}%");
                double desccaneta = valorcaneta * descontopap;
                Console.WriteLine($"O desconto é de {desccaneta}");
                Console.WriteLine($"O valor atual é de {valorcaneta - desccaneta}");
                break;

            case "2":
                Console.Clear();
                Console.WriteLine("Produto escolhido foi Caderno");
                Console.WriteLine("A categoria é Papelaria");
                Console.WriteLine($"O valor do produto era de {valorcaderno}");
                Console.WriteLine($"A porcentagem de desconto é de {descontopap * 100}%");
                double desccaderno = valorcaderno * descontopap;
                Console.WriteLine($"O desconto é de {desccaderno}");
                Console.WriteLine($"O valor atual é de {valorcaderno - desccaderno}");
                break;

            default:
                Console.WriteLine("Opção inválida.");
                break;
        }
        break;

    case "3":
        Console.WriteLine("Qual produto você deseja? ");
        Console.WriteLine("1 - Sofá ");
        Console.WriteLine("2 - Cama ");
        string moveis = Console.ReadLine();

        switch (moveis)
        {
            case "1":
                Console.Clear();
                Console.WriteLine("Produto escolhido foi Sofá");
                Console.WriteLine("A categoria é Móveis");
                Console.WriteLine($"O valor do produto era de {valorsofa}");
                Console.WriteLine($"A porcentagem de desconto é de {descontomov * 100}%");
                double descsofa = valorsofa * descontomov;
                Console.WriteLine($"O desconto é de {descsofa}");
                Console.WriteLine($"O valor atual é de {valorsofa - descsofa}");
                break;

            case "2":
                Console.Clear();
                Console.WriteLine("Produto escolhido foi Cama");
                Console.WriteLine("A categoria é Móveis");
                Console.WriteLine($"O valor do produto era de {valorcama}");
                Console.WriteLine($"A porcentagem de desconto é de {descontomov * 100}%");
                double desccama = valorcama * descontomov;
                Console.WriteLine($"O desconto é de {desccama}");
                Console.WriteLine($"O valor atual é de {valorcama - desccama}");
                break;

            default:
                Console.WriteLine("Opção inválida.");
                break;
        }
        break;

    default:
        Console.WriteLine("Categoria inválida.");
        break;
}



