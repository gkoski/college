﻿
using System;

class Program
{

    static void Main()
    {

        Console.Write("\n Digite o mês (1-12): ");
        int mes = int.Parse(Console.ReadLine());

        Console.Write("Digite o ano: ");
        int ano = int.Parse(Console.ReadLine());


        if (mes < 1 || mes > 12)
        {
            Console.WriteLine("Mês inválido. Digite um valor entre 1 e 12.");
            return;
        }


        string[] meses = { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                           "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" };

        string[] diasSemana = { "D", "S", "T", "Q", "Q", "S", "S" };


        Console.WriteLine($"{meses[mes - 1]} de {ano}");


        string[,] calendario = new string[7, 7];


        for (int i = 0; i < 7; i++)
        {
            calendario[0, i] = diasSemana[i];
        }


        DateTime primeiroDia = new DateTime(ano, mes, 1);
        int diaDaSemana = (int)primeiroDia.DayOfWeek;


        int diasNoMes = DateTime.DaysInMonth(ano, mes);


        int diaAtual = 1;
        for (int linha = 1; linha < 7; linha++)
        {
            for (int coluna = 0; coluna < 7; coluna++)
            {
                if (linha == 1 && coluna < diaDaSemana)
                {
                    calendario[linha, coluna] = "";
                }
                else if (diaAtual <= diasNoMes)
                {
                    calendario[linha, coluna] = diaAtual.ToString();
                    diaAtual++;
                }
                else
                {
                    calendario[linha, coluna] = "";
                }
            }
        }


        for (int linha = 0; linha < 7; linha++)
        {
            for (int coluna = 0; coluna < 7; coluna++)
            {

                if (!string.IsNullOrEmpty(calendario[linha, coluna]))
                {
                    Console.Write(calendario[linha, coluna].PadLeft(3));
                }
                else
                {
                    Console.Write("   ");
                }
            }
            Console.WriteLine();
        }
    }
}
