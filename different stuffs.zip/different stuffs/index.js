
    const divParagrafos = document.getElementById('paragrafos');
    for (let i = 1; i <= 10; i++) {
      const p = document.createElement('p');
      p.textContent = `Texto aleatório.`;
      if (i % 3 === 0) p.classList.add('multiplo3');
      divParagrafos.appendChild(p);
    }

    function gerarTabuada() {
      const valor = parseInt(document.getElementById('valorTabuada').value);
      const resultado = document.getElementById('resultadoTabuada');
      resultado.innerHTML = '';

      if (valor < 1 || valor > 10 || isNaN(valor)) {
        resultado.innerHTML = '<p style="color:red;">Valor inválido, informe valor entre 1-10</p>';
        return;
      }

      let tabuada = '';
      for (let i = 1; i <= 10; i++) {
        tabuada += `${valor} x ${i} = ${valor * i}<br>`;
      }
      resultado.innerHTML = tabuada;
    }

    function calcularMedia() {
      const nota1 = parseFloat(document.getElementById('nota1').value);
      const nota2 = parseFloat(document.getElementById('nota2').value);
      const faltas = parseInt(document.getElementById('faltas').value);
      const resultado = document.getElementById('resultadoMedia');
      const totalAulas = 80;

      const media = (nota1 + nota2) / 2;
      const presenca = ((totalAulas - faltas) / totalAulas) * 100;

      let mensagem = '';
      let classe = '';

      if (presenca < 75) {
        mensagem = 'Reprovado por falta';
        classe = 'reprovado';
      } else if (media < 7) {
        mensagem = 'Reprovado';
        classe = 'reprovado';
      } else {
        mensagem = 'Aprovado';
        classe = 'aprovado';
      }

      resultado.innerHTML = `Média: ${media.toFixed(2)}<br>Presença: ${presenca.toFixed(1)}%<br><span class="${classe}">${mensagem}</span>`;
    }

    let total = 0;

    function adicionarProduto() {
      const nome = document.getElementById('produto').value.trim();
      const valor = parseFloat(document.getElementById('valorProduto').value);
      const tabela = document.querySelector('#tabela tbody');
      const totalSpan = document.getElementById('total');

      if (nome === '' || isNaN(valor) || valor <= 0) {
        alert('Informe um nome de produto válido e um valor maior que zero.');
        return;
      }

      const linha = document.createElement('tr');
      linha.innerHTML = `<td>${nome}</td><td>R$ ${valor.toFixed(2)}</td>`;
      tabela.appendChild(linha);

      total += valor;
      totalSpan.textContent = total.toFixed(2);

      document.getElementById('produto').value = '';
      document.getElementById('valorProduto').value = '';
    }

    function limparLista() {
      document.querySelector('#tabela tbody').innerHTML = '';
      document.getElementById('total').textContent = '0.00';
      total = 0;
    }