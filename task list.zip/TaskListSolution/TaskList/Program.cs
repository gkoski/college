﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static List<string> tarefas = new List<string>();
    static string arquivoNome;

    static void Main()
    {
        arquivoNome = $"nome_sistema_{DateTime.Now:yyyy_MM_dd}.txt";
        Console.WriteLine("Task List");
        if (!File.Exists(arquivoNome))
        {
            File.Create(arquivoNome).Dispose();
        }

        CarregarTarefas();


        while (true)
        {
            ExibirMenu();
            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    ListarTarefas();
                    break;
                case "2":
                    InserirTarefa();
                    break;
                case "3":
                    AlterarTarefa();
                    break;
                case "4":
                    ExcluirTarefa();
                    break;
                case "0":
                    Sair();
                    return;
                default:
                    Console.WriteLine("Opção inválida, tente novamente.");
                    break;
            }
        }
    }

    static void ExibirMenu()
    {
        Console.WriteLine("\nMenu:");
        Console.WriteLine("Digite 1 para listar");
        Console.WriteLine("Digite 2 para inserir novo");
        Console.WriteLine("Digite 3 para alterar");
        Console.WriteLine("Digite 4 para excluir");
        Console.WriteLine("Digite 0 para sair");
        Console.Write("Escolha uma opção: ");
    }

    static void CarregarTarefas()
    {
        tarefas.Clear();
        if (File.Exists(arquivoNome))
        {
            var linhas = File.ReadAllLines(arquivoNome);
            tarefas.AddRange(linhas);
        }
    }

    static void ListarTarefas()
    {
        Console.WriteLine("\nTask List:");
        if (tarefas.Count == 0)
        {
            Console.WriteLine("Nenhuma tarefa cadastrada.");
        }
        else
        {
            for (int i = 0; i < tarefas.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {tarefas[i]}");
            }
        }
    }

    static void InserirTarefa()
    {
        Console.Write("\nDigite a descrição da nova tarefa: ");
        string tarefa = Console.ReadLine();

        tarefas.Add(tarefa);
        AtualizarArquivo();

        Console.WriteLine("Tarefa inserida com sucesso!");
    }

    static void AlterarTarefa()
    {
        ListarTarefas();

        Console.Write("\nDigite o número da tarefa a ser alterada: ");
        if (int.TryParse(Console.ReadLine(), out int numeroTarefa) && numeroTarefa > 0 && numeroTarefa <= tarefas.Count)
        {
            Console.Write("Digite a nova descrição: ");
            tarefas[numeroTarefa - 1] = Console.ReadLine();
            AtualizarArquivo();
            Console.WriteLine("Tarefa alterada com sucesso!");
        }
        else
        {
            Console.WriteLine("Número de tarefa inválido.");
        }
    }

    static void ExcluirTarefa()
    {
        ListarTarefas();

        Console.Write("\nDigite o número da tarefa a ser excluída: ");
        if (int.TryParse(Console.ReadLine(), out int numeroTarefa) && numeroTarefa > 0 && numeroTarefa <= tarefas.Count)
        {
            tarefas.RemoveAt(numeroTarefa - 1);
            AtualizarArquivo();
            Console.WriteLine("Tarefa excluída com sucesso!");
        }
        else
        {
            Console.WriteLine("Número de tarefa inválido.");
        }
    }


    static void AtualizarArquivo()
    {
        File.WriteAllLines(arquivoNome, tarefas);
    }

    static void Sair()
    {
        Console.WriteLine("Saindo da aplicação...");
    }
}
