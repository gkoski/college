﻿using System;

class Programa
{
    static void Main()
    {
        Console.Write("Digite um ano: ");
        string entrada = Console.ReadLine();

        if (int.TryParse(entrada, out int ano))
        {
            if ((ano % 400 == 0) || (ano % 4 == 0 && ano % 100 != 0))
            {
                Console.WriteLine($"O ano {ano} é bissexto");
            }
            else
            {
                Console.WriteLine($"O ano {ano} não é bissexto");
            }
        }
        else
        {
            Console.WriteLine("Valor inválido! Digite um número inteiro.");
        }

        Console.ReadKey();
    }
}
