using System.Linq.Expressions;

namespace avaliativa
{
    public partial class Form1 : Form
    {
        private int contador = 0;

        public Form1()
        {
            InitializeComponent();
        }

        void btn1_Click(object sender, EventArgs e)
        {
            contador = Math.Min(contador + 1, 10);
            lblContador.Text = "N�mero de Cliques: " + contador;
            switch (contador)
            {
                case 7:
                    lblMensagem.Text = "Faltam mais 3 cliques";
                    break;
                case 8:
                    lblMensagem.Text = "Faltam mais 2 cliques";
                    break;
                case 9:
                    lblMensagem.Text = "Mais 1 clique apenas";
                    break;
                case 10:
                    lblMensagem.Text = "Acabou!";
                    break;
                default:
                    lblMensagem.Text = "";
                    break;
            }
 
        }


        private void zerar_Click(object sender, EventArgs e)
        {
            contador = 0;
            lblContador.Text = "N�mero de Cliques: "; 
            lblMensagem.Text = "";
        }
    }
}
