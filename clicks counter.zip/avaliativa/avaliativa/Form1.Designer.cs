﻿namespace avaliativa
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn1 = new Button();
            zerar = new Button();
            Nome = new Label();
            label2 = new Label();
            lblContador = new Label();
            lblMensagem = new Label();
            SuspendLayout();
            // 
            // btn1
            // 
            btn1.Font = new Font("Segoe UI", 20F);
            btn1.Location = new Point(169, 349);
            btn1.Name = "btn1";
            btn1.Size = new Size(199, 56);
            btn1.TabIndex = 0;
            btn1.Text = "Clique aqui";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // zerar
            // 
            zerar.Font = new Font("Segoe UI", 20F);
            zerar.Location = new Point(396, 349);
            zerar.Name = "zerar";
            zerar.Size = new Size(199, 56);
            zerar.TabIndex = 1;
            zerar.Text = "Zerar";
            zerar.UseVisualStyleBackColor = true;
            zerar.Click += zerar_Click;
            // 
            // Nome
            // 
            Nome.AutoSize = true;
            Nome.Font = new Font("Segoe UI", 20F);
            Nome.Location = new Point(12, 9);
            Nome.Name = "Nome";
            Nome.Size = new Size(360, 37);
            Nome.TabIndex = 2;
            Nome.Text = "Gabriel de Carvalho Joukoski";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 20F);
            label2.Location = new Point(12, 63);
            label2.Name = "label2";
            label2.Size = new Size(213, 37);
            label2.TabIndex = 3;
            label2.Text = "RA: 2025104878";
            // 
            // lblContador
            // 
            lblContador.AutoSize = true;
            lblContador.Font = new Font("Segoe UI", 20F);
            lblContador.Location = new Point(212, 145);
            lblContador.Name = "lblContador";
            lblContador.Size = new Size(251, 37);
            lblContador.TabIndex = 4;
            lblContador.Text = "Número de Cliques:";
            lblContador.Click += btn1_Click;
            // 
            // lblMensagem
            // 
            lblMensagem.AutoSize = true;
            lblMensagem.Font = new Font("Segoe UI", 20F);
            lblMensagem.Location = new Point(212, 182);
            lblMensagem.Name = "lblMensagem";
            lblMensagem.Size = new Size(24, 37);
            lblMensagem.TabIndex = 5;
            lblMensagem.Text = " ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblMensagem);
            Controls.Add(lblContador);
            Controls.Add(label2);
            Controls.Add(Nome);
            Controls.Add(zerar);
            Controls.Add(btn1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn1;
        private Button zerar;
        private Label Nome;
        private Label label2;
        private Label lblContador;
        private Label lblMensagem;
    }
}
